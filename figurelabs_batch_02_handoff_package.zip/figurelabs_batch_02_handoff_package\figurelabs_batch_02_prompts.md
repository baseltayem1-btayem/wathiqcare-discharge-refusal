# FigureLabs Batch 2 Prompts

Total procedures: 20

Generate one separate clean PNG per procedure. Do not use screenshots or collage crops.

## 1. Abdominal Aortic Aneurysm

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Abdominal Aortic Aneurysm
Procedure (Arabic): تمدد الأبهر البطني
Specialty: Vascular Surgery
Anatomical region / focus: Abdominal aorta and surrounding arteries
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 2. Abdominoperineal Resection of Rectum

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Abdominoperineal Resection of Rectum
Procedure (Arabic): استئصال المستقيم البطني العجاني
Specialty: General Surgery / Other
Anatomical region / focus: Rectum, anus, perineum, and lower pelvis
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 3. Abdominoplasty

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Abdominoplasty
Procedure (Arabic): تجميل البطن
Specialty: General Surgery / Other
Anatomical region / focus: Abdominal wall and skin
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 4. Adenotonsillectomy

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Adenotonsillectomy
Procedure (Arabic): استئصال اللوزتين والغدة الأدينية
Specialty: Ear, Nose and Throat
Anatomical region / focus: Oropharynx, tonsils, and adenoids
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 5. Allergen Immunotherapy

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Allergen Immunotherapy
Procedure (Arabic): علاج المناعة بالمستضدات
Specialty: Allergy & Immunology
Anatomical region / focus: Upper arm subcutaneous injection site
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 6. Allergy Skin Test consent and informed

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Allergy Skin Test consent and informed
Procedure (Arabic): اختبار الحساسية الجلدي
Specialty: Allergy & Immunology
Anatomical region / focus: Forearm or back skin with test sites
Illustration type: process_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Focus on the care pathway, device, instrument, or procedural steps rather than detailed internal organ anatomy.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 7. Amniocentesis Chorionic Villus Sampling

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Amniocentesis Chorionic Villus Sampling
Procedure (Arabic): أخذ عينة السائل الأمنيوسي أو الزغابات المشيمية
Specialty: Obstetrics & Gynecology
Anatomical region / focus: Uterus, placenta, and amniotic fluid
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 8. Amputation

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Amputation
Procedure (Arabic): بتر العضو
Specialty: General Surgery / Other
Anatomical region / focus: Affected limb and amputation level
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 9. Angiogram with mechanical Thrombectomy (any body part)

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Angiogram with mechanical Thrombectomy (any body part)
Procedure (Arabic): Angiogram with mechanical Thrombectomy (any body part)
Specialty: Radiology / Interventional Radiology
Anatomical region / focus: Whole-body or region-specific CT scanner cross-section
Illustration type: process_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Focus on the care pathway, device, instrument, or procedural steps rather than detailed internal organ anatomy.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 10. Arteriovenous Fistula

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Arteriovenous Fistula
Procedure (Arabic):  fistula دموية شريانية وريدية
Specialty: Vascular Surgery
Anatomical region / focus: Forearm or upper-arm artery and vein connection for dialysis access
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 11. Arteriovenous Goretex Loop Graft

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Arteriovenous Goretex Loop Graft
Procedure (Arabic):  graft جورتكس وريدي شرياني
Specialty: Vascular Surgery
Anatomical region / focus: Forearm or upper-arm artery and vein with synthetic graft for dialysis access
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 12. Arthrogram

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Arthrogram
Procedure (Arabic): تصوير المفصل بالحقن الظليل
Specialty: Orthopedics
Anatomical region / focus: Affected joint and needle/contrast path
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 13. Arthroplasty Consent

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Arthroplasty Consent
Procedure (Arabic): موافقة استبدال المفصل
Specialty: Orthopedics
Anatomical region / focus: Affected joint and surrounding bones
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 14. Aspiration Drainage Under Imaging

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Aspiration Drainage Under Imaging
Procedure (Arabic): Aspiration Drainage Under Imaging
Specialty: Radiology / Interventional Radiology
Anatomical region / focus: Fluid collection and drainage catheter
Illustration type: process_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Focus on the care pathway, device, instrument, or procedural steps rather than detailed internal organ anatomy.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 15. Bartholin's Glands

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Bartholin's Glands
Procedure (Arabic): غدة بارثولين
Specialty: Obstetrics & Gynecology
Anatomical region / focus: Bartholin gland region
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 16. Biopsy Under Imaging

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Biopsy Under Imaging
Procedure (Arabic): أخذ خزعة تحت التصوير الإشعاعي
Specialty: Radiology / Interventional Radiology
Anatomical region / focus: Target lesion and biopsy needle path under imaging
Illustration type: process_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Focus on the care pathway, device, instrument, or procedural steps rather than detailed internal organ anatomy.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 17. Blepharoplasty

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Blepharoplasty
Procedure (Arabic): تجميل الجفن
Specialty: Ophthalmology
Anatomical region / focus: Upper and/or lower eyelids
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 18. Blood and blood products transfusion consent

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Blood and blood products transfusion consent
Procedure (Arabic): Blood and blood products transfusion consent
Specialty: Transfusion Medicine / Blood Transfusion
Anatomical region / focus: Intravenous line, blood bag, and infusion pathway
Illustration type: process_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Focus on the care pathway, device, instrument, or procedural steps rather than detailed internal organ anatomy.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 19. Breast Abscess Haematoma

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Breast Abscess Haematoma
Procedure (Arabic): خراج أو ورم دموي في الثدي
Specialty: Breast Surgery
Anatomical region / focus: Breast abscess cavity
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 20. Breast Biopsy Aspiration

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Breast Biopsy Aspiration
Procedure (Arabic): خزعة أو شفط الثدي
Specialty: Breast Surgery
Anatomical region / focus: Breast tissue and target lesion
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```
