# FigureLabs Batch 3 Handoff Package

## Scope
Generate **20 separate, clean PNG illustrations** for the procedures listed in 
`figurelabs_batch_03_priority_20.csv`.

## Global requirements for every image
- One separate PNG per procedure. No composite images, no screenshots, no collage crops.
- Patient-friendly, non-graphic, non-bloody, hospital-grade education style.
- Landscape orientation, high resolution, suitable for informed consent display.
- English labels with space for Arabic overlays.
- White or very light background.
- Leave a blank area at the bottom for the informed consent disclaimer.
- No hospital logos, no watermarks, no patient-identifiable information.

## Output naming
Use the exact filenames in `figurelabs_batch_03_expected_filenames.csv`.
Do not rename files.

## Output paths
Store images under the project paths in `figurelabs_batch_03_expected_public_paths.csv`.

## Authorization certificates
Provide a separate authorization certificate for each illustration.
Expected certificate filenames are listed in `figurelabs_batch_03_expected_filenames.csv`.

## Prompts
Copy/paste prompts are in `figurelabs_batch_03_prompts.md`.

## Manual review items
Arabic translations marked "subject to clinical review" are in
`figurelabs_batch_03_manual_review_items.csv`.

## Status
- production_status: pending_figurelabs_generation
- imageReviewStatus: pending_generation
- integration_status: not_integrated
