# FigureLabs Batch 3 Prompts

Total procedures: 20

Generate one separate clean PNG per procedure. Do not use screenshots or collage crops.

## 1. Breast Microdochotomy

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Breast Microdochotomy
Procedure (Arabic): جراحة قنوات الثدي الدقيقة
Specialty: Breast Surgery
Anatomical region / focus: Breast duct and nipple area
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 2. Breast Wide LocaL Excision

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Breast Wide LocaL Excision
Procedure (Arabic): استئصال محدود في الثدي
Specialty: Breast Surgery
Anatomical region / focus: Breast tissue and target lesion
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 3. Burch Colposuspension

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Burch Colposuspension
Procedure (Arabic): تعليق عنق الرحم برباط كوبر
Specialty: General Surgery / Other
Anatomical region / focus: Anatomy specific to Burch Colposuspension
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 4. Burns

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Burns
Procedure (Arabic): الحروق
Specialty: General Surgery / Other
Anatomical region / focus: Affected skin and superficial tissue layers
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 5. Burns (Child-Young Person)

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Burns (Child-Young Person)
Procedure (Arabic): Burns (Child-Young Person)
Specialty: General Surgery / Other
Anatomical region / focus: Affected skin and superficial tissue layers
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 6. Capsule Endoscopy

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Capsule Endoscopy
Procedure (Arabic): تنظير الكبسولة
Specialty: Gastroenterology / Hepatobiliary Surgery
Anatomical region / focus: Small intestine with capsule endoscope
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 7. Cardioversion

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Cardioversion
Procedure (Arabic): إعادة ضبط القلب بالصدمات الكهربائية
Specialty: Cardiology
Anatomical region / focus: Chest, heart, and external defibrillator pads
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 8. Carotid Endarterectomy

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Carotid Endarterectomy
Procedure (Arabic): استئصال بطانة الشريان السباتي
Specialty: Vascular Surgery
Anatomical region / focus: Carotid artery in the neck
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 9. Carotid Stenting

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Carotid Stenting
Procedure (Arabic): تركيب دعامة في الشريان السباتي
Specialty: Vascular Surgery
Anatomical region / focus: Carotid artery in the neck
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 10. Catheter Check with IV Iodinated Contrast

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Catheter Check with IV Iodinated Contrast
Procedure (Arabic): Catheter Check with IV Iodinated Contrast
Specialty: Radiology / Interventional Radiology
Anatomical region / focus: Existing catheter and contrast injection path
Illustration type: process_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Focus on the care pathway, device, instrument, or procedural steps rather than detailed internal organ anatomy.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 11. Cautery to Cervix

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Cautery to Cervix
Procedure (Arabic): كي عنق الرحم
Specialty: Obstetrics & Gynecology
Anatomical region / focus: Cervix
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 12. Cerebral Angiogram - Aneurysm Coiling - Flow Diverter

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Cerebral Angiogram - Aneurysm Coiling - Flow Diverter
Procedure (Arabic): تصوير شرايين الدماغ مع لف التمدد أو جهاز تحويل التدفق
Specialty: Neurosurgery / Neuro-interventional Radiology
Anatomical region / focus: Brain arteries and aneurysm
Illustration type: process_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Focus on the care pathway, device, instrument, or procedural steps rather than detailed internal organ anatomy.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 13. Cerebral Vasospasm Treatment

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Cerebral Vasospasm Treatment
Procedure (Arabic): علاج تشنج شرايين الدماغ
Specialty: Neurosurgery / Neuro-interventional Radiology
Anatomical region / focus: Brain arteries at the base of the skull
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 14. Chalazion Curettage

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Chalazion Curettage
Procedure (Arabic): كحت الكلازيون
Specialty: Ophthalmology
Anatomical region / focus: Eyelid and meibomian gland
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 15. Chemabrasion and Dermabrasion

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Chemabrasion and Dermabrasion
Procedure (Arabic): تقشير الجلد الكيميائي والميكانيكي
Specialty: Plastic / Dermatologic Surgery
Anatomical region / focus: Anatomy specific to Chemabrasion and Dermabrasion
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 16. Cholangiogram (Percutaneous) &or Biliary DrainStent

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Cholangiogram (Percutaneous) &or Biliary DrainStent
Procedure (Arabic): تصوير القنوات الصفراوية أو تصريف/دعامة صفراوية
Specialty: Gastroenterology / Hepatobiliary Surgery
Anatomical region / focus: Bile ducts and biliary tree
Illustration type: process_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Focus on the care pathway, device, instrument, or procedural steps rather than detailed internal organ anatomy.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 17. Cholecystectomy Open

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Cholecystectomy Open
Procedure (Arabic): استئصال المرارة بالجراحة المفتوحة
Specialty: Gastroenterology / Hepatobiliary Surgery
Anatomical region / focus: Gallbladder, liver, bile ducts, upper right abdomen
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 18. Cholecystectomy Open and Exploration of the Common Bile Duct

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Cholecystectomy Open and Exploration of the Common Bile Duct
Procedure (Arabic): Cholecystectomy Open and Exploration of the Common Bile Duct
Specialty: Gastroenterology / Hepatobiliary Surgery
Anatomical region / focus: Gallbladder, liver, bile ducts, upper right abdomen
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 19. Cholecystoduodenostomy - Enterostomy

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Cholecystoduodenostomy - Enterostomy
Procedure (Arabic): Cholecystoduodenostomy - Enterostomy
Specialty: Gastroenterology / Hepatobiliary Surgery
Anatomical region / focus: Anatomy specific to Cholecystoduodenostomy - Enterostomy
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```

## 20. Circumcision - (Adult)

```text
Create a patient-friendly, non-graphic, non-bloody medical illustration for informed consent education.

Procedure (English): Circumcision - (Adult)
Procedure (Arabic): ختان البالغين
Specialty: Urology
Anatomical region / focus: Penis and foreskin
Illustration type: anatomy_procedure_education

Requirements:
- Clean, professional, hospital-grade patient education style
- Show the relevant human anatomy clearly and the basic concept of the procedure, including the instrument or treatment path when applicable.
- Use soft clinical colors on a white or very light background
- Label the main anatomical structures or steps clearly in English
- Leave adequate space for Arabic label overlays
- Include short callout labels for the procedural target or key step
- Do not include any patient-identifiable information, hospital logos, watermarks, or frightening imagery
- Landscape orientation, high resolution, suitable for informed consent display
- Include a blank area at the bottom for the informed consent disclaimer
```
