# Engineering Integration Guide — Batch 3

## After FigureLabs delivers the PNGs
1. Receive the generated PNG files and authorization certificates.
2. Copy the PNGs into `apps/web/public/educational/clinical-illustrations/` using the exact folder structure and filenames from `figurelabs_batch_03_expected_public_paths.csv`.
3. Place authorization certificates under `docs/clinical-illustrations/figurelabs/<canonicalProcedureKey>/`.
4. Open `apps/web/src/lib/server/clinical-knowledge/migration/figurelabs-batch-data.ts`.
   - Convert the Batch 3 keys into full `BatchIllustration` records.
   - Set `imageReviewStatus: "approved"` and `patientFacing: true` only after formal clinical and Arabic translation review.
   - Set the actual `procedureImageUrl` paths.
   - Apply the clinically reviewed Arabic names from `figurelabs_batch_03_manual_review_items.csv`.
5. Update `apps/web/src/lib/server/clinical-knowledge/migration/seed-from-imc.ts` to iterate the Batch 3 approved records (same pattern as Batch 1).
6. Regenerate the registry:
   ```bash
   cd apps/web
   npx tsx scripts/generate-figurelabs-registry.ts
   npx tsx scripts/generate-figurelabs-batch-03.ts
   npx tsx scripts/generate-figurelabs-batch-03-checklist.ts
   ```
7. Run validation and checks:
   ```bash
   npx tsx scripts/validate-figurelabs-registry.ts
   npx tsx --test src/lib/server/clinical-knowledge/migration/seed-from-imc.test.ts
   npx tsc --noEmit
   npx eslint ...
   npm run build
   ```
8. Commit and push.

## Current status
- production_status: pending_figurelabs_generation
- imageReviewStatus: pending_generation
- integration_status: not_integrated
- Seed mapping: not yet wired to Batch 3 images.
